<?php
  require_once 'include/db.php';
?>

<?php
session_start();
  $userid = $_SESSION['userid'];
  if(isset($_POST["update"])){
    move_uploaded_file($_FILES['file'] ['tmp_name'],"uploads/".$_FILES['file']['name']);
    // $conn = mysqli_connect("localhost", "root", "", "penny_pocket");
    $q =  mysqli_query($conn, "UPDATE users SET profile_image = '".$_FILES['file']['name']."' WHERE usersID = '$userid';");
  }
?>
<!DOCTYPE html>
<html lang="en-US">
  <head>
  <title>Profile</title>
  <link rel="stylesheet" href="libs/css/bootstrap.min.css">
<style>
  .img{
margin-right:1000px;
vertical-align:right;
  }
  .profile-input-field{
    float:right;
    padding:20px 30px;
margin-right:800px;
margin-top:-12cm;
  }
  .profright{
    margin-left:650px;
  }
  </style>
  </head>
  <body>
  <?php include 'include/header.php' ?>
  <div class="profright">
  <h1 style="color: #023232; text-shadow: 5px 5px 7px #D4AF37;margin-top:2cm;padding:20px 20px;">User Profile </h1>
  <br>
<div class="container4" style="margin-left:250px;margin-top:-2cm;">
<h4 style=" text-decoration: underline;padding:10px 180px;">Profile Picture</h4>
<?php 
    // $conn = mysqli_connect("localhost", "root", "", "penny_pocket");
    $q = mysqli_query ($conn, "SELECT * FROM users where usersID= $userid;");
    
    while($row = mysqli_fetch_assoc($q)){
      if($row["profile_image"] == ""){
         echo "<img width='430' height='430' src='uploads/avatar.png' alt='Default profile'>"; 
      } else {
        echo "<img width='430' height='430' src='uploads/".$row["profile_image"]."' alt='profile'>";
      }
      echo "<br>";
    }
  ?>
  <br>
  <form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="file">
    <input type="submit" name="update" value="UPDATE" style="background-color: #428bca; padding:6px 12px; border-radius: 4px; color:white; width: 14em;margin-left:3.6cm;">
  </form> 

  </div></div>


  <?php

$query=mysqli_query($conn,"SELECT * FROM users where usersID='$userid'")or die(mysqli_error());
$row=mysqli_fetch_array($query);
  ?>
  <br>
  <center>
  
<div class="profile-input-field" style="margin-left:250px";>
<h4  style="text-decoration: underline;">Profile Information</h4>
        <form method="post" action="">
          <div class="form-group">
            <label>Fullname:</label>
            <input type="text" class="form-control" name="fullname" style="width:20em;" placeholder="Enter your Fullname" value="<?php echo $row['fullName']; ?>"  />
          </div>
          <div class="form-group">
            <label>Username:</label>
            <input type="text" class="form-control" name="username" style="width:20em;" placeholder="Enter your Username"  value="<?php echo $row['usersName']; ?>" />
          </div>
          <div class="form-group">
            <label>Email:</label>
            <input type="text" class="form-control" name="email" style="width:20em;" placeholder="Enter your Email" value="<?php echo $row['usersEmail']; ?>">
          </div>
          <div class="form-group">
            <input type="submit" name="submit" class="btn btn-primary" style="width:20em; margin:0;"><br><br>
          </div>
        </form>
</div> </center>
    
    <?php
    
      if(isset($_POST['submit'])){
        $fullname = $_POST['fullname'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        
        $query=mysqli_query($conn,"UPDATE users SET fullName = '$fullname', usersName = '$username', usersEmail = '$email'
    WHERE usersID = '$userid';")or die(mysqli_error());
        // $id = $_POST['userid'];
      // $query = "UPDATE users SET fullName = '$fullname', usersName = '$username', usersEmail = '$email'
      //                 WHERE usersID = '$id';";
                    ?>
                     <script type="text/javascript">
            alert("Update Successful.");
            window.location = "profile.php";
        </script>      
     <?php  $_SESSION['username'] = $username; ?>
        <?php
             }              
?>

								<?php include_once 'include/sidebar.php'; ?>

                </body>
                  </html>