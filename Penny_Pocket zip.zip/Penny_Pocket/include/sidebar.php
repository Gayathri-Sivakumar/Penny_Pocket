<?php
// session_start();
require 'include/db.php';
// require 'include/functions.inc.php';
$userid=$_SESSION['userid'];
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

<style>
body {
  font-family: "verdana", sans-serif;
  background-color:beige;
}

.sidenav {
  height: 100%;
  width: 290px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:#022525;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 2px 1px 1px 5px;
  text-decoration: none;
  font-size: 19px;
  color: #D4AF37;
  display: block;
  background-color: #023232;
  border-radius: 25px 25px 25px 25px;
}

.sidenav a:hover {
  color: olive;
}

.main {
  margin-left: 200px;
  padding: 0px 0px;
}

.btn button {
  background-color: silver; 
  border: 1px solid green;  
  padding: 10px 15px; 
  cursor: pointer; /* Pointer/hand icon */
  width: 100%; /* Set a width if needed */
  display: block; /* Make the buttons appear below each other */
}

.btn button:not(:last-child) {
  border-bottom: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn button:hover {
  background-color:darkkhaki;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.title {
    font-size: 25px;
    color:#D4AF37;
}
.userpic img{
  border-radius:50%;
}

</style>
</head>
<body>

<div class="sidenav">
  <?php       
  //  $conn = mysqli_connect("localhost", "root", "", "penny_pocket");
   $q = mysqli_query ($conn, "SELECT * FROM users where usersID= $userid;");
   $row = mysqli_fetch_assoc ($q);
   ?> <center><div class="userpic"> <?php
   if($row["profile_image"] == ""){
    echo "<img width='200' height='200' src='uploads/avatar.png' alt='Default profile'>"; 
 } else {
   echo "<img width='200' height='200' src='uploads/".$row["profile_image"]."' alt='profile'>";
 }
  // echo "<img width='200' height='200' src='uploads/".$row["profile_image"]."' alt='profile'>";
?></div> </center>
         <div class="profile-sidebar">
     
      <center> <div class="title">
    
<?php 
$query=mysqli_query($conn,"SELECT usersName FROM users where usersID='$userid'");
$row=mysqli_fetch_array($query);
$username=$row['usersName'];
$_SESSION['username']= $username;
echo $username; ?></div></center>

        <div class="divider"></div>
        
        <div class="btn">
        <ul class="nav menu">
            <button><li class="active"><a href="dashboard.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li></button>
            
            
           
            <button><li class="parent "><a data-toggle="collapse" href="#sub-item-1">
                <em class="fa fa-navicon">&nbsp;</em>Expenses <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
                </a> </button>
                <ul class="children collapse" id="sub-item-1">
                    <li><a class="" href="expense.php">
                        <span class="fa fa-arrow-right">&nbsp;</span> Add & Manage
                    </a></li>
                    <li><a class="" href="expenseschart.php">
                        <span class="fa fa-arrow-right">&nbsp;</span> Expenses Chart
                    </a></li>
                    
                </ul>

            </li>
           

    <button>  <li class="parent "><a data-toggle="collapse" href="#sub-item-2">
                <em class="fa fa-navicon">&nbsp;</em>Income <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
                </a> </button>
                <ul class="children collapse" id="sub-item-2">
                    <li><a class="" href="income.php">
                        <span class="fa fa-arrow-right">&nbsp;</span> Add & Manage
                    </a></li>
                    <li><a class="" href="incomechart.php">
                        <span class="fa fa-arrow-right">&nbsp;</span> Income Chart
                    </a></li>
                    
                </ul>
            </li>

    <button><li class="parent "><a data-toggle="collapse" href="#sub-item-3">
            <em class="fa fa-navicon">&nbsp;</em>Monthwise Report <span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="fa fa-plus"></em></span>               
            </a> </button>
            <ul class="children collapse" id="sub-item-3">
                <li><a class="" href="expensereportform.php">
                    <span class="fa fa-arrow-right">&nbsp;</span> Expenses
                </a></li>
                <li><a class="" href="incomereportform.php">
                    <span class="fa fa-arrow-right">&nbsp;</span> Income
                </a></li>
            </ul>
            </li>


        <button> <li><a href="todo.php"><em class="fa fa-book">&nbsp;</em>Todo-List</a></li> </button>  
         <button> <li><a href="profile.php"><em class="fa fa-user">&nbsp;</em> Profile</a></li> </button>
         <button>  <li><a href="changepassword.php"><em class="fa fa-clone">&nbsp;</em> Change Password</a></li> </button>
         <button> <li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li> </button>

        </ul>
        </div>
    </div>
    </body>
</html>