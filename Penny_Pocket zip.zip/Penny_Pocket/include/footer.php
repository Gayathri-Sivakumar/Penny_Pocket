<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <style>
    /* 
---------------------------------------------
footer
--------------------------------------------- 
*/
footer {
    background-image: linear-gradient(127deg, #023232 0%, #D4AF37 115%);
    padding-top: 30px;
    position:scroll;
  }
  
  footer .social {
    overflow: hidden;
    margin-top: 10px;
    text-align: center;
  }
  
  footer .social li {
    margin: 0px 10px;
    display: inline-block;
  }
  
  footer .social li a {
    color: #023232;
     text-align: center;
    background-color: #fff;
    width: 36px;
    height: 36px;
    line-height: 36px;
    border-radius: 50%;
    display: inline-block;
    font-size: 16px;
    -webkit-transition: all 0.3s ease 0s;
    -moz-transition: all 0.3s ease 0s;
    -o-transition: all 0.3s ease 0s;
    transition: all 0.3s ease 0s;
  }
  
  footer .social li a:hover {
    background-color:#7e7272;
    color: #fff;
  }
  
  footer .copyright {
    text-align: center;
    border-top: 1px solid rgba(250,250,250,0.2);
    margin-top: 30px;
    padding-top: 30px;
    padding-bottom: 30px;
    font-weight: 400;
    font-size: 12px;
    color: #fff;
    letter-spacing: 0.88px;
    text-transform: uppercase;
  }
  
  @media (max-width: 991px) {
    footer .text {
      margin-bottom: 30px;
    }
    footer h5 {
      margin-bottom: 15px;
    }
    footer .footer-nav {
      margin-bottom: 30px;
    }
  }
  </style>
</head>
<body>
    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <ul class="social">
                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright &copy; 2021 INTERPRETERS - Design: Team Interpreters</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>