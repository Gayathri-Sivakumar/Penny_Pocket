<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <style>


@import url("https://fonts.googleapis.com/css?family=Raleway:100,300,400,500,700,900");

ul, li {
  padding: 0;
  margin: 0;
  list-style: none;
}

header, nav, section, article, aside, footer, hgroup {
  display: block;
}

* {
  box-sizing: border-box;
}

html, body {
  font-family: "Raleway", sans-serif;
  font-weight: 400;
  background-color: #204d53;
  font-size: 16px;
  -ms-text-size-adjust: 100%;
  
}

a {
  text-decoration: none !important;
}
.logo img{
    height:100px;
    width: 100px;
    margin:-1.3cm;
    margin-left:0.5cm;
}

h1, h2, h3, h4, h5, h6 {
  margin-top: 0px;
  margin-bottom: 0px;
}

ul {
  margin-bottom: 0px;
}

/* 
---------------------------------------------
global styles
--------------------------------------------- 
*/
html,
body {
  background:#ffffff;
  font-family: "Raleway", sans-serif;
}    
/* 
---------------------------------------------
header
--------------------------------------------- 
*/
.header-area {
  position: fixed;
  top: 0px;
  left: 22%;
  right: 0px;
  z-index: 100;
  height: 100px;
}
.header-area .main-nav {
  box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
  border-radius: 40px;
  min-height: 80px;
  background: #fff; 
}

.header-area .main-nav .logo {
  float: left;
  margin-top: 37px;
  -webkit-transition: all 0.3s ease 0s;
  -moz-transition: all 0.3s ease 0s;
  -o-transition: all 0.3s ease 0s;
  transition: all 0.3s ease 0s;
  margin-left: 30px;
}


.header-area .main-nav .nav {
  float: right;
  margin-top: 21px;
  margin-left: 0px;
  margin-right: 40px;
  position: relative;
  z-index: 999;
}

.header-area .main-nav .nav li {
  padding-left: 25px;
  padding-right: 25px;
}

.header-area .main-nav .nav li:last-child {
  padding-right: 0px;
}

.header-area .main-nav .nav li a {
  display: block;
  font-weight: 500;
  font-size: 15px;
  color: rgb(0, 0, 0);
  font-weight: 600;
  line-height: 40px;
  border: transparent;
  letter-spacing: 1px;
}

.header-area .main-nav .nav li a:hover {
  color: #023232;
}

.header-area .main-nav .menu-trigger {
  cursor: pointer;
  display: block;
  position: absolute;
  top: 20px;
  height: 40px;
  text-indent: -9999em;
  z-index: 99;
  right: 40px;
  display: none;
}

.header-area.header-sticky {
  min-height: 80px;
}

.header-area.header-sticky .logo {
  margin-top: 37px;
}
@media (max-width: 1200px) {
  .header-area .main-nav .nav li {
    padding-left: 12px;
    padding-right: 12px;
  }
  .header-area .main-nav:before {
    display: none;
  }
}

@media (max-width: 991px) {
  .header-area {
    padding: 0px 15px;
    height: 80px;
    box-shadow: none;
    text-align: center;
  }
  .header-area .container {
    padding: 0px;
  }
  .header-area .logo {
    margin-top: 27px !important;
    margin-left: 30px;
  }
  .header-area .menu-trigger {
    display: block !important;
  }
  .header-area .main-nav {
    overflow: hidden;
  }
  .header-area .main-nav .nav {
    float: none;
    width: 100%;
    margin-top: 80px !important;
    display: none;

    margin-left: 0px;
  }
  .header-area .main-nav .nav li:first-child {
    border-top: 1px solid #023232;
  }


  .header-area .main-nav .nav li a:hover {
    background: #eee !important;
  }
}

@media (min-width: 992px) {
  .header-area .main-nav .nav {
    display: flex !important;
  }
}
  </style>
</head>
<body>
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav" style="width:1000px;">
                        <div class="logo">
                            <img src="img/logo.png" alt="Penny Pocket"/>
                        </div>
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><b><a href="home.html">Home</a></b></li>
                            <li><b><a href="review.html">Reviews</a></b></li>
                            <li><b><a href="aboutus.html">About Us </a></b></li>
                            <li><b><a href="contactus.php">Contact Us</a></b></li>
                        </ul>
                   
                
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
    
</body>

</html>