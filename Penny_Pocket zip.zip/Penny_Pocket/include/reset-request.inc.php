<?php

if(isset($_POST["request-submit"])){
    $selector= bin2hex(random_bytes(8));
    $token = random_bytes(32);

    $url = "http://localhost/Penny_Pocket/create-new-password.php?selector=".$selector."&validator=".bin2hex($token);
    $expires = date("U")+1800;

    require 'db.php';
    $useremail = $_POST["email"];
    $sql = "DELETE FROM pwdreset WHERE pwdResetEMAIL=?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        echo "There was an error";
        exit(); 
    }
    else{
        mysqli_stmt_bind_param($stmt, "s",$useremail);
        mysqli_stmt_execute($stmt);
    }
    $sql = "INSERT INTO pwdReset (pwdResetEmail, pwdResetSelector, pwdResetToken, pwdResetExpires) VALUES (?,?,?,?); ";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        echo "There was an error";
        exit(); 
    }
    else{
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($stmt, "ssss",$useremail, $selector, $hashedToken, $expires);
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    $to = $useremail;
     
    $subject = 'Reset your password for PennyPocket';

    $message = "<p>We received a password reset request. the link to reset your password is below. If you did not make any requests, you can ignore this Email</p>";
    $message .= "<Here is your password reset link: <br>";
    $message .= '<a href= "' .$url.'">'.$url. '</a></p>';
    $headers = "From: PennyPocket <kamsajiny@gmail.com>\r\n";
    $headers = "Reply-to: kamsajiny@gmail.com\r\n";
    $headers = "Content-type: text/html\r\n";

    //mail($to, $subject, $headers);
    // $mail->AddAddress($to);
    // $mail->Body = $message;
    // $mail->Subject = $subject;
    // $mail->Username = 'kamsayiny@gmail.com';
    // $mail->Password = 'skamsa98@';
    header("Location: ../reset-password.php?reset=success");

}
else{
    header("Location: ../login.php");
}
// ?>
// <?php
use phpmailer\phpmailer\phpmailer;

require_once 'Exception.php';
require_once 'PHPMailer.php';
require_once 'SMTP.php';

$mail = new PHPMailer(true);

$alert ='';
if(isset($_POST['request-submit'])){
    if( filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
    // $name = $_POST['name'];
    // $email = $_POST['email'];
    // $message = $_POST['message'];

    
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kamsayiny@gmail.com';//Gmail address which we want to use as SMTP
        $mail->Password = 'skamsa98@';// gmail address pasword
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port = '587';

        $mail->setFrom('kamsayiny@gmail.com');// your email address which you used as SMTP server 
        $mail->addAddress($to);//email address where you want to recieve emails (you can use any of your gmail address including which you using for SMTP)

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = "$message";

        $mail->send();
    }
}
       