<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/style.css?v=35678676799">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
    <div class="image">
        <img src="img/pic13.png" width=1000px height=800px>

        <style>
          
.image{

position:fixed;

margin-top: -1.5cm;
margin-left: 6.5cm;

}</style>
    </div>
   <div class="container2">
   <img src="img/icon2.png">
    <div class="heading"><p>Log In</p></div>
    <div class="conta">
 
        <form action="include/login.inc.php" method="POST">
        
           <label>Username/Email:</label>
           <input type="text" placeholder="Enter username/email" name="username" required>
           <label>Password:</label>
           <input type="password" placeholder="Enter your password" name="password" required>
           <a href="reset-password.php">forget your username or password?</a>
           
            
           <button type="submit" name="submit">Log In</button>
          
          <div class="pp"> Don't have an account?</div><a href="signup.php"><div class="sign">Sign up</div></a>
         </div>
        </form>
        </div>
    </div>
    <button class='button1'>
          <a href="home.html">HOME >>></a>
         </button>
        <?php 
        if(isset($_GET["error"])){
          if($_GET["error"]=="emptyinput"){
              echo "<p>All necessary fields must be filled</p>";
          }
          else if($_GET["error"]=="wrongLogin"){
            echo "<p>incorrect login ..Try again!</p>";
          }
          else if($_GET["error"]=="wrongLogin2"){
            echo "<p>incorrect login warning..Try again!</p>";
          }
        } 
        ?>

    </body>
        
</html>
      
    
  