<?php
  session_start();
  require 'include/db.php';
  if (strlen($_SESSION["userid"]==0)) {
	header('location:logout.php');
	}
  ?>
<!DOCTYPE html>
<html>
<head>
 <?php include 'include/header.php'; ?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Penny Pocket || Monthwise Expense Report</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<style>
	body{
		overflow-x:hidden;
	}
	footer {
    background-image: linear-gradient(127deg, #023232 0%, #D4AF37 115%);
    padding-top: 40px;
    position: relative;
    margin-top: 49px;
    left:65px;
	width:1400px;
  }
  
  
	</style>
</head>
<body>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" style="margin-left:420px; width:800px; margin-top:100px;">
	<p>Hey, <?php echo $_SESSION['username']; ?>!</p>
				
		<div class="row">
			<div class="col-lg-12">		
				<div class="panel panel-default">
					<div class="panel-heading">Monthwise Expense Report</div>
					<div class="panel-body">

						<div class="col-md-12">
					
<?php
$fdate=$_POST['fromdate'];
 $tdate=$_POST['todate'];
 $_SESSION['fdate'] = $fdate;
$_SESSION['tdate'] = $tdate;
?>
<h5 align="center" style="color:blue">Monthwise Expense Report from <?php echo $fdate?> to <?php echo $tdate?></h5>
<hr />
          <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
             <thead>
                       <tr>
               <tr>
              <th>S.NO</th>
              <th>Month</th>
              <th>Expense Amount</th>
                </tr>
                </tr>
             </thead>
 <?php
 $totalsexp=0;
$userid=$_SESSION["userid"];
$result=mysqli_query($conn,"SELECT month(date) as rptmonth,SUM(amount) as totalmonth  FROM expense where (date BETWEEN '$fdate' and '$tdate') && (usersID=$userid) group by month(date)");
$cnt=1; 
while($row= $result->fetch_assoc()){
		?>             
                <tr>
				  <td><?php echo $cnt;?></td>
				  <td><?php  echo $row['rptmonth']?></td>
                  <td><?php echo $exp= $row['totalmonth'];?></td>
                </tr>
				<?php
				$totalsexp+=$exp; 
$cnt=$cnt+1;
}?>

 <tr>
  <th colspan="2" style="text-align:center">Grand Total</th>     
  <td><?php echo $totalsexp;?></td>
 </tr>     
  </table>
  <form role="form" method="post" action="pdf_expense.php">
  
  <button type="submit" id="pdf" class="btn btn-primary" name="generate_pdf"><i class="fa fa-pdf" aria-hidden="true">Generate PDF</button>
  </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
	
</body>
<div class="footer" style="zoom:98%; margin-left:230px;"><?php include 'include/footer.php'; ?> </div>
<?php include 'include/sidebar.php'; ?> 
</html>
