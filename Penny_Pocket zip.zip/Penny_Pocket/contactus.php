<?php include 'sendemail.php'; ?>
<?php include 'header.php'; ?>


<!doctype HTML>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<title>Contact</title>
<link href="css/contactstyles.css?v46esd34535" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
<style>
      body{
        background:linear-gradient(rgba(0, 0, 0, 0.8),rgba(3, 51, 17, 0.8)),url("img/a.jpg");
    }
    </style>
  
</head>
<body>
   <?php echo $alert; ?>
 <div class="contact-section">
  <div class="contact-info">
    
  <div><i class="fas fa-envelope"></i>Interpreters@gmail.com</div>
  <div><i class="fas fa-phone"></i>+9999999999</div>
  </div>
    <div class="contact-form">
  <h2>Contact us</h2> 
  <form class="contact" action="contactus.php" method="post">
    <input type="text" name="name" class="text-box" placeholder="Your Name" required>
    <input type="email" name="email" class="text-box" placeholder="Your email" required>
    <textarea name="message" rows="5" placeholder="Your message" required></textarea>
    <input type="submit" name="submit" class="send-btn" value="Send">
  </form>
  </div>
 </div>
<?php include 'footer.php'; ?>

 <!--contact section end -->
<script type="text/javascript">
if(window.history.replaceState){
  window.history.replaceState(null, null, window.location.href);
}
</script>
</body>
</html>

