
<?php  if(isset($_SESSION['megs'])):?>
<?php endif ?> 
  <?php require_once 'budget.php';?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Client area</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 <style>

 .container3 {
  position: absolute;
  zoom: 95%;
  text-align:center;
  width:800px;
  left:480px;
  top:80px;
  margin-top:10px;
 }
 .li{
  position: absolute;
  zoom: 88%;
  text-align:center;
  width:80%;
  height:40%;
  left:330px;
  top:460px;
  margin-top:10px;
  }

 .box{
  display:flex;
  flex-direction:row;
  justify-content:space-evenly;
  position: absolute;
  zoom: 80%;
  align-items:center;
  width:80%;
  height:40%;
 left:370px;
  top:650px;
  margin-top:10px;
 }
 .box2{
  display:flex;
  flex-direction:row;
  justify-content:space-evenly;
  position: absolute;
  zoom: 80%;
  align-items:center;
  width:80%;
  height:40%;
  left:370px;
  top:1050px;
  margin-top:10px;
 }
  
  .f1 {
    
    background-color:whitesmoke;
    box-shadow: 0 15px 20px rgba(0,0,0,0.30), 0 11px 8px rgba(0,0,0,0.22);
    box-sizing: border-box;
    border-radius:30px;
    zoom: 90%;
    height:300px;
    width:300px;
    padding:20px 380px;
    padding-right:20px;
    transition-duration:2s;
  
      }
      .f1:hover{
        zoom: 100%;
  }
 .f1 img {
         width:240px ;
         height:230px;
         margin-left:-8cm;
         margin-top:0cm;

 }
 .f1 h4 {
      font-family: sans-serif;
      margin-left:-9cm;
      font-size:24px;
  }

  footer {
    position:absolute;
    background-image: linear-gradient(127deg, #023232 0%, #D4AF37 115%);
    position: relative;
    top:340px;
    bottom:0px;
    margin-top: 850px;
    margin-left:225px;
  }
  footer i{
    margin-top:10px;
  }
  
 
 </style>
</head>
<body>
 <?php include_once 'include/header.php'; ?>
 <div class="container3">    
    <div class="row">
      <div class="col-lg-12">
        <h1 style="color: #023232; text-shadow: 5px 5px 5px #D4AF37; font-size:60px;"><strong>Dashboard</strong></h1>
      </div>
    </div><!--/.row-->
    
    <div class="form">
        <h3><strong>Hey, <?php echo $_SESSION['username']; ?>!</strong></h3>
        <h3><strong>Welcome to Penny Pocket!</strong></h3>
    </div>
   <form action="budget.php" method="POST">
     <div class="form-group">
         <label for="budgetValue">Set the Budget.</label>
         <input type="text" name="budget" class="form-control" id="budget" placeholder="Enter Amount" required >
     </div>
             <button type="submit" name="save" class="btn btn-primary btn-block">Save</button>
            <?php 
                    if(isset($_SESSION['megs'])){
                        echo    "<div class='alert alert-{$_SESSION['msg_type']} alert-dismissible fade show ' role='alert'>
                                    <strong> {$_SESSION['megs']} </storng>
                                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                        <span aria-hidden='true'>&times;</span>
                                    </button>
                                </div>";
                    }
            ?>
  
    </form>
  </div>
  <center><div class="li">
   <h2><strong>Budget: Rs.<?php echo $budgets?></strong></h2> 
   <h2><strong>Budget balance: Rs.<?php echo $balance;?></strong></h2>
 </div></center>
 <div class="box">

  <div class="f1">
    <img src="img/totalexpense.jpg">
    <h4>Total Expenses=Rs.<?php echo $expensestotal?>.</h4>
  </div>

  <div class="f1">
    <img src="img/i1.jpg">
    <h4> Total Income =Rs.<?php echo $Totlincome  ?>.</h4>
  </div>
</div>


<div class="box2">
   <div class="f1">
    <img src="img/E2.png">
    <h4>Today's Expense =Rs.<?php 
      if($sum_today_expense==""){
              echo "0";
              } else {
                echo $sum_today_expense;
       }?>
    </h4>
   </div>
   <div class="f1">
    <img src="img/E3.jpg">
    <h4 >Yesterday's Expense =Rs. <?php
     if($sum_yesterday_expense==""){
              echo "0";
              } else {
                echo $sum_yesterday_expense;
      }?>
    </h4>
   </div>
</div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
</body>
<?php include_once 'include/footer.php'; ?>
<?php include_once 'include/sidebar.php'; ?> 

</html>