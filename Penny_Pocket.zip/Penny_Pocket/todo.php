<?php
  session_start();
  require 'include/db.php';
  if (strlen($_SESSION["userid"]==0)) {
	header('location:logout.php');
	}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="shortcut icon" type="image/x-icon" href="pin.ico" />

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Handlee|Rock+Salt&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="css/todo_style.css">

  <title>To do List</title>
<style>
.sidebar a {
	font-size:14px;
}
footer {
    position:absolute;
    background-image: linear-gradient(127deg, #023232 0%, #D4AF37 115%);
    position: relative;
    top:340px;
    bottom:0px;
    margin-top: -8cm;
    margin-left:225px;
   zoom:85%;
  }
  footer i{
    margin-top:10px;
  }
  ul{
    padding-top:0px;
  }

</style>
</head>

<body>
    
  <?php
 $userid = $_SESSION['userid'];
      // initialize errors variable
    $errors = "";

    // insert a quote if submit button is clicked
    if (isset($_POST['submit'])) {
      if (empty($_POST['task'])) {
        $errors = "*You must fill in the task";
      }else{
        $task = $_POST['task'];
        $sql = "INSERT INTO tasks (usersID,task) VALUES ('$userid','$task')";
        mysqli_query($conn, $sql);
        header('location: todo.php');
      }
    }
    if (isset($_GET['del_task'])) {
  $id = $_GET['del_task'];

  mysqli_query($conn, "DELETE FROM tasks WHERE id='$id'");
  header('location: todo.php');
}

?>
  <!-- h1>Lorem5 press tab -->
  <div class="container">

  <div class="row justify-content-center">

  <ul>
      <li>

          <div class="content">

            <p class="title"><b>Penny_Pocket_TO DO LIST:</b></p>

            <form method="post" action="todo.php" class="input_form">
              <?php if (isset($errors)) { ?>
          	<p><?php echo $errors; ?></p>
          <?php } ?>

          		<input type="text" name="task" class="task_input">
          		<button type="submit" name="submit" id="add_btn" class="add_btn">Add Task</button>

          	</form><p style="font-size:10px;color:red;">*Click Task name to mark it done.</p>
            <center>
            <table>
            	<thead>
            		<tr>
            			<th>No.</th>
            			<th>Tasks</th>
            			<th style="width: 60px;">Action</th>
            		</tr>
            	</thead>

            	<tbody>
            		<?php
            		// select all tasks if page is visited or refreshed
            		$tasks = mysqli_query($conn, "SELECT * FROM tasks WHERE usersID = '$userid'");

            		$i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>
            			<tr>
            				<td class="number" width="10"> <?php echo $i; ?> </td>
            				<td class="task"> <?php echo $row['task']; ?> </td>
            				<td class="action">
            					<a href="todo.php?del_task=<?php echo $row['id'] ?>" >Remove</a>
            				</td>
            			</tr>
            		<?php $i++; } ?>
            	</tbody>
            </table></center>

            </div>
          </div>
      </li>
    </ul>
</div>
</div>
<script>

// Add a "checked" symbol when clicking on a list item
$(function(){
  var $curParent, Content;
  $(document).delegate("td.task","click", function(){
    if($(this).closest("s").length) {
      Content = $(this).parent("s").html();
      $curParent = $(this).closest("s");
      $(Content).insertAfter($curParent);
      $(this).closest("s").remove();
    }
    else {
      $(this).wrapAll("<s />");
    }
  });
});
</script>

<?php include 'include/footer.php'; ?> 
<div class="side"><?php
include 'include/sidebar.php';
?></div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</html>