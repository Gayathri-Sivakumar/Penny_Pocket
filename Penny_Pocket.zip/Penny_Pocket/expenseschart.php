<?php
session_start();
require 'include/db.php';
if (strlen($_SESSION["userid"]==0)) {
  header('location:logout.php');
  } else{
 $userid=$_SESSION["userid"];
 $query="SELECT name,sum(amount) as Type FROM expense WHERE usersID=$userid GROUP BY name";
 $result=mysqli_query($conn,$query);
  }?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Expense chart</title>
</head>
<body>
<?php include 'include/header.php' ?>

<br><br><br>
<center><div id="piechart" style="width:900px; margin-left:300px;"></div></center>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['name', 'Type'],
  <?php
 while($row=mysqli_fetch_array($result))
 {
   echo"['".$row["name"]."',".$row["Type"]."],";
 }?>
]);


  var options = { 'title':'My Expenses','width':600, 'height':450, 'pieHole':0.5,titleTextStyle: {color:'#023232',fontName: 'Times New Roman',fontSize: 24,bold:true },
}


  //to show the chart inside.
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

</body>
<div class="footer" style="zoom:98%; margin-left:200px;margin-top:15px;"><?php include 'include/footer.php'; ?> </div> 
<?php include_once 'include/sidebar.php'; ?> 
</html>