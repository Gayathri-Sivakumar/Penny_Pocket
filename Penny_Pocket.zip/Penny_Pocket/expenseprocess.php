<?php
session_start();
require 'include/db.php';
if (strlen($_SESSION["userid"]==0)) {
  header('location:logout.php');
  } else{
// variable declaration
$expensestotal = 0;
$update = false;
$id=0;
$name = '';
$amount = '';
$userid=$_SESSION["userid"];


//store data
    if(isset($_POST['save'])){
       
        $expense = $_POST['name'];
        $amount = $_POST['amount'];
        $date = $_POST['date'];
    
        $query = mysqli_query($conn, "INSERT INTO expense (usersID,name, amount, date) VALUE ('$userid','$expense', '$amount','$date')"); 
        
        $_SESSION['message'] = "Record has been saved !";
        $_SESSION['msg_type'] = "primary";

        header("location: expense.php");
        

    }

    //calculate Total expenses
    $result = mysqli_query($conn, "SELECT * FROM expense WHERE usersID=$userid");
    while($row = $result->fetch_assoc()){
        $expensestotal =$expensestotal + $row['amount'];
        $_SESSION['expenses']=$expensestotal;
    }

    //delete data

    if(isset($_GET['delete'])){
        $id = $_GET['delete'];

        $query = mysqli_query($conn, "DELETE FROM expense WHERE id=$id");
        $_SESSION['message'] = "Record has been Delete !";
        $_SESSION['msg_type'] = "danger";

        header("location: expense.php");

    }


    //edit data

    if(isset($_GET['edit'])){
        $id = $_GET['edit'];
        $update = true;
        $result = mysqli_query($conn,"SELECT * FROM expense WHERE id=$id");

      
        if( mysqli_num_rows($result) == 1){
            $row = $result->fetch_assoc();
            $name = $row['name'];
            $amount = $row['amount'];
            $date = $row['date'];
        }
    
    }

    //update data

    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $expense = $_POST['name'];
        $amount = $_POST['amount'];
        $date = $_POST['date'];

        $query = mysqli_query($conn, "UPDATE expense SET name='$expense', amount='$amount', date='$date' WHERE id='$id'");
        $_SESSION['message'] = "Record has been Updated !";
        $_SESSION['msg_type'] = "success";
        header("location: expense.php");
    }
}

?>