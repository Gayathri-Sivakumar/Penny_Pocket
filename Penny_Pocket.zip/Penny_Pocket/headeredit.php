<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
      <style>
    /* 
---------------------------------------------
header
--------------------------------------------- 
*/
.header-area {
  position:scroll;
  top: 30px;
  left: 0px;
  right: 0px;
  z-index: 100;
  height: 100px;
}
.header-area .main-nav {
  box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
  border-radius: 40px;
  min-height: 80px;
  background: #fff; 
}

.header-area .main-nav .logo {
  float: left;
  margin-top: 37px;
  -webkit-transition: all 0.3s ease 0s;
  -moz-transition: all 0.3s ease 0s;
  -o-transition: all 0.3s ease 0s;
  transition: all 0.3s ease 0s;
  margin-left: 30px;
}

.header-area .main-nav .logo img {
  -webkit-transition: all 0.3s ease 0s;
  -moz-transition: all 0.3s ease 0s;
  -o-transition: all 0.3s ease 0s;
  transition: all 0.3s ease 0s;
}

.header-area .main-nav .nav {
  float: right;
  margin-top: 27px;
  margin-left: 0px;
  margin-right: 30px;
  position: relative;
  z-index: 999;
}

.header-area .main-nav .nav li {
  padding-left: 20px;
  padding-right: 20px;
}

.header-area .main-nav .nav li:last-child {
  padding-right: 0px;
}

.header-area .main-nav .nav li a {
  display: block;
  font-weight: 500;
  font-size: 13px;
  color: rgb(0, 0, 0);
  font-weight: 600;
  line-height: 40px;
  border: transparent;
  letter-spacing: 1px;
}

.header-area .main-nav .nav li a:hover {
  color: #023232;
}

.header-area .main-nav .menu-trigger {
  cursor: pointer;
  display: block;
  position: absolute;
  top: 23px;
  width: px;
  height: 40px;
  text-indent: -9999em;
  z-index: 99;
  right: 40px;
  display: none;
}

.header-area.header-sticky {
  min-height: 80px;
}

.header-area.header-sticky .logo {
  margin-top: 25px;
}
@media (max-width: 1200px) {
  .header-area .main-nav .nav li {
    padding-left: 12px;
    padding-right: 12px;
  }
  .header-area .main-nav:before {
    display: none;
  }
}

@media (max-width: 991px) {
  .header-area {
    padding: 0px 15px;
    height: 80px;
    box-shadow: none;
    text-align: center;
  }
  .header-area .container {
    padding: 0px;
  }
  .header-area .logo {
    margin-top: 27px !important;
    margin-left: 30px;
  }
  .header-area .menu-trigger {
    display: block !important;
  }
  .header-area .main-nav {
    overflow: hidden;
  }
  .header-area .main-nav .nav {
    float: none;
    width: 100%;
    margin-top: 80px !important;
    display: none;

    margin-left: 0px;
  }
  .header-area .main-nav .nav li:first-child {
    border-top: 1px solid #023232;
  }


  .header-area .main-nav .nav li a:hover {
    background: #eee !important;
  }
}

@media (min-width: 992px) {
  .header-area .main-nav .nav {
    display: flex !important;
  }
}
.button1{
  background-color:#053a1b;
  border: none;
  border-radius: 45%;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px; 
  margin-right: 5px;
  cursor: pointer;
}
button a:link, a:visited {
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

.button2
{
  border-radius: 45%;
  background-color:#D4AF37;
  border: none;
  padding: 15px 32px;
  text-align: center;
  margin-left: 5px;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  cursor: pointer; 
  
}
body
{
  background-color:rgb(2, 32, 32);
  color:azure;
  height: 500px;
}
.container2
{
background-color:rgb(197, 206, 206);
border:1px;
color:rgb(2, 32, 32);
padding: 12px 15px;
border-radius: 5%;
width: 40%;
margin-left: 350px;
}

.container2 input
{
  width: 100%;
  padding: 12px 160px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
/*
.container2 label
{
  font-size: 20px;
  float centre;
}
*/


    </style>
     <!--<link rel="stylesheet" href="css/style.css">-->
    </head>

    <body>
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <div class="logo">
                           <!--<img src="logo.png" alt="Penny Pocket"/>-->
                        </div>
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><b><a href="header2.php" class="active">Home</a></b></li>

                            <?php
                            if(isset($_SESSION["username"])) { 
                                echo "<li><b><a href='##'>Reviews</a></b></li>";
                                echo "<li><b><a href='##'>About Us </a></b></li>";
                                echo "<li><b><a href='##'>Contact Us</a></b></li>";
                                echo "<button class='button2'>
                                          <a href='include/logout.inc.php'>Log out</a>
                                      </button>";
                            }
                            else {
                                echo "<li><b><a href='#'>Reviews</a></b></li>";
                                echo "<li><b><a href='#'>About Us </a></b></li>";
                                echo "<li><b><a href='#'>Contact Us</a></b></li>";
                                echo "<button class='button1'>
                                        <a href='signup.php'>Sign up</a>
                                      </button>";
                                echo "<button class='button2'>
                                        <a href='login.php'>Log In</a>
                                      </button>";
                            }
          
                            ?>
        
                        </ul>
                       <!-- <button class="button1">
                            <a href="signin.php">Sign In</a>
                           </button>
                           <button class="button2">
                            <a href="login.php">Log In</a>
                           </button>-->
                   
                
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
    
</body>

</html>      