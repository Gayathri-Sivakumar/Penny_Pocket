 <?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/style.css?v=35678676799">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
    <div class="image">
        <img src="img/pic13.png" width=1000px height=800px>

        <style>
          
.image{

position:fixed;

margin-top: -1.5cm;
margin-left: 6.5cm;

}</style>
    </div>
   <div class="container2">
   <img src="img/icon2.png">
    <div class="heading"><p>Reset Password</p></div>
    <div class="conta">
 
    <form action="include/reset-request.inc.php" method="POST">
        <label>Email:</label>
        <input type="text" placeholder="Enter user email..." name="email" required>
           
            
        <div class="reset"> <button type="submit" name="request-submit">RESET</button></div>
          
          <div class="ppp"> <p>An email will be sent to you with instructions on how to reset your password</p></div></a>
         </div>
        </form>
        </div>
    </div>
    <button class='button1'>
          <a href="home.html">HOME >>></a>
         </button>
         <?php
        if(isset($_GET["reset"])){
          if($_GET["reset"]=="success"){
              echo "<p>check your email!</p>";
          }
        }
        ?>

    </body>
        
</html>     
    
  