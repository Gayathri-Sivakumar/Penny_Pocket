  <?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/style.css?v=35678676799">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
    <div class="image">
        <img src="img/pic13.png" width=1000px height=800px>

        <style>
          
.image{

position:fixed;

margin-top: -1.5cm;
margin-left: 6.5cm;

}</style>
    </div>
   <div class="container2">
   <img src="img/icon2.png">
    <div class="heading"><p>Create New Password</p></div>
    <div class="conta">
 
    <?php
         $selector = $_GET["selector"];
         $validator = $_GET["validator"];

       
             if(ctype_xdigit($selector)!==false && ctype_xdigit($validator)!==false) {
                 ?>
           <form action= "include/reset-password.inc.php" method = "post">
           <input type="hidden" name="selector" value = "<?php echo $selector?>" >
           <input type="hidden" name="validator" value = "<?php echo $validator?>">
           <input type="password" placeholder="Enter your new password" name="password" required>
           <input type="password" placeholder="Confirm password" name="confirm_password" required>
           <button type="submit" name="reset-password-submit">Reset password</button>
           <?php
             }
        // }


        ?>
            
         </div>
         
        </form>
        </div>
    </div>
    <button class='button1'>
          <a href="home.html">HOME >>></a>
         </button>
       

    </body>
        
</html>  