<?php require_once 'incomeprocess.php'; ?>
<?php  if(isset($_SESSION['message'])): ?>
<?php endif ?> 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penny Pocket</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <style>

.list {
    margin-left:1cm;
}

.form-group {
    margin-left:0.5cm;
}
.text-center{
    margin-top:80px;
}
.custom-select{
    font-size:13px;
   
}
footer {
    background-image: linear-gradient(127deg, #023232 0%, #D4AF37 115%);
    padding-top: 40px;
    position: relative;
    margin-top: 52px;
    margin-left:130px;
  }
  
</style>

</head>
<body>
<?php include 'include/header.php'; ?> 
    <br><br><br>
    <div class="container" style="margin-left:300px;">
        <div class="row">
            <div class="col-md-4">
                <h2 class="text-center">Add Income</h2>
                <hr><br>
                <form action="incomeprocess.php" method="POST">
                    <div class="form-group">
                        <label for="budgetTitle">Income Type</label>
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <select name="name" class="browser-default custom-select" >
                           <option value="" disabled selected>Select Income Type</option>
                           <option value="Mahapola/burcery" >Mahapola/burcery</option>
                           <option value="ParentMoney">Parent Money</option>
                           <option value="BankWithdrawal" >Bank Withdrawal</option>
                           <option value="giftedmoney">Gifted Money</option>
                           <option value="OtherIncome">Other Income</option>
                        </select>                        
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="text" name="amount" class="form-control" id="amount" placeholder="Enter Amount" required  value="<?php echo $amount; ?>">
                        <label for="date">Date</label>
                        <input type="date" name="date" class="form-control" id="date" placeholder="Enter Date" required  value="<?php echo $date; ?>">
                    </div>
                    <?php if($update == true): ?>
                    <button type="submit" name="update" class="btn btn-success btn-block" style="width:314px; margin-left:36px;">Update</button>
                    <?php else: ?>
                    <button type="submit" name="save" class="btn btn-primary btn-block" style="width:314px; margin-left:36px;">Save</button>
                    <?php endif; ?>
                </form>
            </div>
            <div class="col-md-8">
                <h2 class="text-center">Total Income : Rs.<?php echo $Totlincome;?></h2>
                <hr>
                <br><br>

                <?php 

                    if(isset($_SESSION['message'])){
                        echo    "<div class='alert alert-{$_SESSION['msg_type']} alert-dismissible fade show ' role='alert'>
                                    <strong> {$_SESSION['message']} </storng>
                                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                        <span aria-hidden='true'>&times;</span>
                                    </button>
                                </div>
                                ";
                    }

                ?>
               <div class="list"> <h2>Income List</h2>

                <?php 
                     $userid=$_SESSION['userid'];
                    $result = mysqli_query($conn, "SELECT * FROM income WHERE usersID=$userid");
                ?>
                <div class="row justify-content-center">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Income Name</th>
                                <th>Amount</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <?php 
                            while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['date']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td> Rs. <?php echo $row['amount']; ?></td>
                                <td>
                                    <a href="income.php?edit=<?php echo $row['id']; ?>" class="btn btn-success">edit</a>
                                    <a href="incomeprocess.php?delete=<?php echo $row['id']; ?>"  class="btn btn-danger">delete</a>
                                </td>
                            </tr>
                                <?php endwhile?>
                    </table>
            </div>
        </div>
      </div> 
      </div> 
      </div> 
      </div>  
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>    
</div>
</body>
<div class="footer"><?php include 'include/footer.php'; ?> </div> 
<?php include 'include/sidebar.php'; ?> 
</html>