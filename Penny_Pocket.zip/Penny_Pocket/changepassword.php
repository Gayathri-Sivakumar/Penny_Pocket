<?php
session_start();
require_once 'include/functions.inc.php';
include('include/db.php');
error_reporting(0);
if (strlen($_SESSION['userid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
{
$userid=$_SESSION['userid'];
$username=$_SESSION["username"];
$UIDexist=usernameExists($conn, $username, $username);
$cpassword=$_POST['currentpassword'];
$paswordHashed = $UIDexist["usersPassword"];
$checkedPassword = password_verify($cpassword, $paswordHashed);

if($checkedPassword === false){
  echo "<script>alert('incorrect password. Please try again');</script>";
 }
 else if($checkedPassword === true){
$newpassword=$_POST['newpassword'];
$hashednewpassword=password_hash($newpassword, PASSWORD_DEFAULT);
$ret=mysqli_query($conn,"UPDATE users SET usersPassword='$hashednewpassword' WHERE usersID='$userid'");
echo "<script>alert('Your password successully changed');</script>";
 }
}
  }
  ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Penny_Pocket_Change Password</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script type="text/javascript">
function checkpass()
{
if(document.changepassword.newpassword.value!=document.changepassword.confirmpassword.value)
{
alert('New Password and Confirm Password field does not match');
document.changepassword.confirmpassword.focus();
return false;
}
return true;
} 
</script>

<style>
 /*body{
   overflow: hidden;
 }

 .form-group{
   width:500px;
 }

 .panel-heading {
  text-align:center;
   font-weight:bold; 
   font-size:20px;
 }*/
 .col-md-12{
   padding:10px 0px;
 }
 .form-group{
   width:350px;
 }
 body{
     background-color:black;
     overflow-x:hidden;
     height:100%;
   }
   .panel{
     padding:50px 50px;
     margin-left:300px;
     border-style:double;
     background-color:black;
     width:600px;
     position:absolute;
     margin-top:500px;
  
   }
   .panel-heading{
     font-size:30px;
     padding:10px 100px;
     font-family:monospace;
   }
   .btn{
     font-size:20px;
     padding:10px 30px;
   }
   button{
     margin-left:170px;
   }
  
  footer{
    margin-left:160px;
  }

</style>
</head>

<body> 
<?php include 'include/header.php' ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" style="margin-left:305px; width:1045px; background-color:black;">
     <div class="row" >
      <div class="col-lg-12" style="background-color:grey;">
          
        <div class="panel panel-default" style="margin-top:90px;">
       <center><div class="panel-heading">Change Password</div></center>
          <div class="panel-body" style="background-color:biege;">
            <p style="font-size:16px; align:center;"></p>
            <div class="col-md-12" style="background-color:beige;">
               
       <center> <form role="form" method="post" action="" name="changepassword" onsubmit="return checkpass();">
                <div class="form-group">
                  <label>Current Password</label>
                  <input type="password" name="currentpassword" class=" form-control" required= "true" value="">
                </div>
                <div class="form-group">
                  <label>New Password</label>
                  <input type="password" name="newpassword" class="form-control" value="" required="true">
                </div>
                
                <div class="form-group">
                  <label>Confirm Password</label>
                  <input type="password" name="confirmpassword" class="form-control" value="" required="true">
                </div>
                
                <div class="form-group has-success">
                  <button type="submit" class="btn btn-primary" name="submit">Change</button>
                </div>
                </div>
              </form> </center>
              
            </div>
          </div>
        </div><!-- /.panel-->
      </div><!-- /.col-->
    </div><!-- /.row --> 
</div><!--/.main-->
  
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 

<div style="zoom:90%; margin-left:335px;"><?php include 'footer.php'; ?> </div>
</body>
<?php include 'include/sidebar.php'; ?> 
</html>