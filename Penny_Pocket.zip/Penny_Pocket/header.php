<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <style>
           @import url("https://fonts.googleapis.com/css?family=Raleway:100,300,400,500,700,900");

ul, li {
  padding: 0;
  margin: 0;
  list-style: none;
color:
}

* {
  box-sizing: border-box;
}

html, body {
  font-family: "Raleway", sans-serif;
  font-weight: 400;
  background-image: linear-gradient(127deg, #023232 0%, #D4AF37 85%);
  font-size: 16px;

}
body{
  background:linear-gradient(rgba(0, 0, 0, 0.5),rgba(65, 65, 65, 0.8));
 background-repeat: no-repeat;
  
}

a {
  text-decoration: none !important;
}
.logo img{
    height:130px;
    width: 130px;
    margin:-1.3cm;
    margin-left:0.5cm;
}
/* 
---------------------------------------------
header
--------------------------------------------- 
*/
.header-area {
  position: fixed;
  top: 10px;
  left: 10%;
  right: 10%;
  z-index: 100;
  height: 100px;
}
.header-area .main-nav {
  box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
  border-radius: 40px;
  min-height: 80px;
  background: #fff; 
}

.header-area .main-nav .logo {
  float: left;
  margin-top: 37px;
  margin-left: 30px;
}

.header-area .main-nav .nav {
  float: right;
  margin-top: 11px;
  margin-right: 40px;
  position: relative;
  z-index: 999;
  display: flex;
  flex-wrap: nowrap;
  background-color: rgb(255, 255, 255);

}

.header-area .main-nav .nav li {
    background-color: #ffffff;
    width: 120px;
    margin: 10px;
    text-align: center;
    line-height: 95px;
    font-size: 40px;
  
}

.header-area .main-nav .nav li:last-child {
  padding-right: 0px;
}

.header-area .main-nav .nav li a {
  display: block;
  font-weight: 500;
  font-size: 15px;
  color: rgb(0, 0, 0);
  font-weight: 600;
  line-height: 40px;
  border: transparent;
  letter-spacing: 1px;
}

.header-area .main-nav .nav li a:hover {
  color: #ffffff;
  background-color: #D4AF37;
}


.header-area .main-nav .menu-trigger {
  cursor: pointer;
  display: block;
  position: absolute;
  top: 20px;
  height: 40px;
  text-indent: -9999em;
  z-index: 99;
  right: 40px;
  display: none;
}

.header-area.header-sticky {
  min-height: 80px;
}

.header-area.header-sticky .logo {
  margin-top: 25px;
}
@media (max-width: 1200px) {
  .header-area .main-nav .nav li {
    padding-left: 12px;
    padding-right: 12px;
  }
  .header-area .main-nav:before {
    display: none;
  }
}

@media (max-width: 991px) {
  .header-area {
    padding: 0px 15px;
    height: 80px;
    box-shadow: none;
    text-align: center;
  }
  .header-area .container {
    padding: 0px;
  }
  .header-area .logo {
    margin-top: 27px !important;
    margin-left: 30px;
  }
  .header-area .menu-trigger {
    display: block !important;
  }
  .header-area .main-nav {
    overflow: hidden;
  }
  .header-area .main-nav .nav {
    float: none;
    width: 100%;
    margin-top: 80px !important;
    display: none;

    margin-left: 0px;
  }
  .header-area .main-nav .nav li:first-child {
    border-top: 1px solid #023232;
  }


  .header-area .main-nav .nav li a:hover {
    background: #eee !important;
  }
}

@media (min-width: 992px) {
  .header-area .main-nav .nav {
    display: flex !important;
  }
}
.btn1{
  background-color:#053a1b;
  border: none;
  border-radius: 5%;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-top: 0.5cm;
  margin-left: 3cm;
  cursor: pointer;
}
.btn1 a:link, a:visited {
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
.btn a:link, a:visited {
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
.btn:hover
{
  color:rgb(106, 107, 12);
}
.btn1:hover
{
  color:rgb(8, 65, 38);
}
.btn
{
  background-color:#D4AF37;
  border: none;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-top: -0.126cm;
  cursor: pointer;
}
    </style>
    </head>
    
    <body>

    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <div class="logo">
                            <img src="img/logo.png" alt="Penny Pocket"/>
                        </div>
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><b><a href="home.html" class="active">Home</a></b></li>
                            <li><b><a href="review.html">Reviews</a></b></li>
                            <li><b><a href="aboutus.html">About Us </a></b></li>
                            <li><b><a href="contactus.php">Contact Us</a></b></li>
                        </ul>
                        <button class="btn1">
                            <a href='signup.php'>Sign Up</a>
                           </button>
                           <button class="btn">
                            <a href='login.php'>Log In</a>
                           </button>
                   
                
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
</body>
</html>