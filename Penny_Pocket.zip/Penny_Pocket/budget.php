<?php
session_start();
require 'include/db.php';
if (strlen($_SESSION["userid"]==0)) {
  header('location:logout.php');
  } else{
$budgets=0;
$balance=0;
$expensestotal = 0;
$update = false;
$Totlincome = 0;
$userid=$_SESSION['userid'];


if(isset($_POST['save'])){ 
  $budget = $_POST['budget'];
  $query = mysqli_query($conn, "UPDATE users SET budget='$budget' WHERE usersID='$userid'"); 
  header("location: dashboard.php");
}


//Total Expense
$result = mysqli_query($conn, "SELECT * FROM expense WHERE usersID=$userid");
while($row = $result->fetch_assoc()){
    $expensestotal =$expensestotal + $row['amount'];
}

//Total Income
$ret = mysqli_query($conn, "SELECT * FROM income  WHERE usersID=$userid");
    while($row = $ret->fetch_assoc()){
        $Totlincome= $Totlincome+ $row['amount'];
    }

    //calculate balance
$result = mysqli_query($conn, "SELECT budget as budgetamount FROM users WHERE usersID=$userid");
    while($row = $result->fetch_assoc()){
      $budgets= $row['budgetamount'];
      $balance=$budgets - $expensestotal;
    }

  if($balance>0){
    $_SESSION['megs'] = "YOU are good to GO!";
    $_SESSION['msg_type'] = "success";
  }else if($balance===0){
    $_SESSION['megs'] = "Now you are in your budget line!";
    $_SESSION['msg_type'] = "danger";
  }else if($balance<0){
    $_SESSION['megs'] = "Your Expences are over your Budget line.!";
    $_SESSION['msg_type'] = "danger";
  }

//Today Expense
$userid=$_SESSION['userid'];
$tdate=date('Y-m-d');
$query=mysqli_query($conn,"SELECT SUM(amount)  AS expense FROM expense WHERE (date)='$tdate' && (usersID='$userid');");
$result=mysqli_fetch_array($query);
$sum_today_expense=$result['expense'];


//Yestreday Expense
$userid=$_SESSION['userid'];
$ydate=date('Y-m-d',strtotime("-1 days"));
$query1=mysqli_query($conn,"SELECT SUM(amount)  AS yesterdayexpense FROM expense WHERE (date)='$ydate' && (usersID='$userid');");
$result1=mysqli_fetch_array($query1);
$sum_yesterday_expense=$result1['yesterdayexpense'];
  }
?>