<?php
ob_start();
session_start();
include_once("include/db.php");
require('fpdf/fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('img/logo.png',0,0,60,60,'png');
    $this->SetFont('Times','B',30,true);
    $this->SetTextColor(101,128,37);
    // Move to the right
    $this->Cell(50);
    $this->Cell(70,20,'Penny Pocket',0,1,'C');
    // Title
    $this->SetFont('Times','B',25);
    $this->Cell(50);
    $this->Cell(70,20,'Monthwise Report',0,'C');
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}


$pdf = new PDF();
$fdate=$_SESSION['fdate'];
$tdate=$_SESSION['tdate'];
$userid=$_SESSION["userid"];
//header
$pdf->AddPage();
//footer page
$pdf->AliasNbPages();

$pdf->SetFont('Times','B',20);
$pdf->Cell(103,10,'Monthwise Income Report from',0,0);
$pdf->Cell(37,10,$fdate,0,0);
$pdf->Cell(10,10,'to',0,0);
$pdf->Cell(35,10,$tdate,0,1);
$pdf->Ln(15);

$pdf->SetFont('Times','B',20);
$pdf->Cell(10,10,'',0);
$pdf->Cell(50,10,'SNO.',1,0,'C');
$pdf->Cell(50,10,'Month',1,0,'C');
$pdf->Cell(70,10,'Amount',1,1,'C');

$pdf->SetFont('Arial','B',14);
$result=mysqli_query($conn,"SELECT month(date) as rptmonth,SUM(amount) as totalmonth  FROM income where (date BETWEEN '$fdate' and '$tdate') && (usersID=$userid) group by month(date)")or die("database error:". mysqli_error($conn));
$total=0;
$cnt=1;
while(($row= $result->fetch_assoc())){
    $pdf->Cell(10,10,'',0);
    $pdf->Cell(50,10,$cnt,1,0,'C');
    $pdf->Cell(50,10,$row['rptmonth'],1,0,'C');
    $pdf->Cell(70,10,number_format($row['totalmonth']),1,1,'R');
    $total+=$row['totalmonth']; 
    $cnt=$cnt+1;

}
$pdf->Cell(60,10,'',0);
$pdf->Cell(50,10,'Grand Total',1,0,'C');
$pdf->Cell(70,10,number_format($total),1,1,'R');

$pdf->Output();
ob_end_flush();
?>