<?php
use phpmailer\phpmailer\phpmailer;

require_once 'include/Exception.php';
require_once 'include/PHPMailer.php';
require_once 'include/SMTP.php';

$mail = new PHPMailer(true);

$alert ='';
if(isset($_POST['submit'])){
    if( filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    try{
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kamsayiny@gmail.com';//Gmail address which we want to use as SMTP
        $mail->Password = 'skamsa98@';// gmail address pasword
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port = '';

        $mail->setFrom('kamsayiny@gmail.com');// your email address which you used as SMTP server 
        $mail->addAddress('kamsayiny@gmail.com');//email address where you want to recieve emails (you can use any of your gmail address including which you using for SMTP)

        $mail->isHTML(true);
        $mail->Subject = 'Message received (penny pocket contact page)';
        $mail->Body = "<h3>Name : $name <br>Email: $email <br>Message :$message</h3>";

        $mail->send();
        $alert = '<div class="alert-success">
                  <span>Message Sent! Thank you for contacting us.</span>
                </div>';
    } catch (Exception $e){
        $alert = '<div class="alert-error">
                    <span>message error</span>
                  </div>';
    
    }
    }
   else{
    $alert = '<div class="alert-error">
    <span>Sorry.You entered invalid email address!!</span>
  </div>';
       
   }
    }
?>